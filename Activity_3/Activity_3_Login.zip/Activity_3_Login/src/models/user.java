package models;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

@ManagedBean(name="user")
@SessionScoped
public class user {

	private String username;
	private String password;
	
	public void setUsername (String username) {
		this.username = username;
	}
	public String getUsername () {
		return this.username;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getPassword() {
		return password;
	}
	public void login() {
		System.out.println("Success");
	}
}
